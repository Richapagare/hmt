package com.Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.Database.ConnectionProvider;

public class UserAuthenticator {

	
	public boolean isLogin(User user)
	
	{
		String username=user.getUsername();
		String password=user.getPassword();
		String tablepassword="";
		ConnectionProvider cp=new ConnectionProvider();
		Connection con=cp.getCon();
	
		try
		{
			System.out.println("Connection open");
			String query="select password from login where loginname='"+username+"'";
			System.out.println(query);
			System.out.println(username);
			System.out.println(password);
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			
			if(rs.next())
			{
				tablepassword=rs.getString("password");
				
						
			}
		}
		
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		if(username!=null && password!=null && password.equals(tablepassword))
		{
			return true;
		}
		
		else
		{
			return false;
		}
	}
	
	public boolean isAdmin(User user)
	
	{
		String username=user.getUsername();
		String password=user.getPassword();
		
		if(username!=null && password!=null && username.equals("admin") && password.equals("admin"))
		{
			return true;
		}
		
		else
		{
			return false;
		}
	
	}
}
