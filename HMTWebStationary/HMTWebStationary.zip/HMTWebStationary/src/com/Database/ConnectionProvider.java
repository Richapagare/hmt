package com.Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

	static Connection con=null;
	
	public static Connection getCon()
	{ 
		try{
			Class.forName("oracle.jdbc.OracleDriver");

			 con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		
		}
		catch (ClassNotFoundException | SQLException e){
			
			System.out.println(e);
		}
	
	return con;
	}
	
	
}
